package com.liam.demoweb.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.liam.demoweb.model.Product;

@Service
public class ProductService {

    List<Product> products = new ArrayList<>(Arrays.asList(
    new Product(101, "iPhone", 50000),
    new Product(100, "Android", 5000),
    new Product(500, "Nothing", 10000)
    ));

    public List<Product> getProducts(){
        return products;
    }

    public Product getProductByID(int prodID){
        return products.stream().filter(p -> p.getProdID() == prodID).findFirst().get();
    }

    public void addProduct(@RequestBody Product prod){
        products.add(prod);
    }

    public void updateProduct(Product prod) {
        int index=0;
        for (int i=0; i<products.size(); i++){
            if(products.get(i).getProdID() == prod.getProdID())
                index = i;
        }
        products.set(index,prod);
    }

    public void deleteProduct(Product prod){
        int index=0;
        for (int i=0; i<products.size(); i++){
            if(products.get(i).getProdID() == prod.getProdID())
                index = i;
        }
        products.remove(index);
    }
}

