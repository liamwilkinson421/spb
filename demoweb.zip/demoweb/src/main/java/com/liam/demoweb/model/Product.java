package com.liam.demoweb.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Product {

    private Integer prodID;
    private String prodname;
    private Integer price;
    @Override
    public String toString() {
        return "Product [prodID=" + prodID + ", prodname=" + prodname + ", price=" + price + "]";
    }

    
    
}
